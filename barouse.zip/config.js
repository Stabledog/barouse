import { fetchConfigFromGitHub, pushConfigToGitHub } from "./github-sync.js";
import { validateMetabrowseUrl } from "./veditor-launch.js";

const STORAGE_KEY = "barouse_config";

export function getDefaultConfig() {
  return {
    sites: [
      { url: "https://example.com", label: "Example" }
    ]
  };
}

export function validateConfig(config) {
  if (!config || typeof config !== "object") {
    return { valid: false, error: "Config must be an object" };
  }
  if (!Array.isArray(config.sites)) {
    return { valid: false, error: "Config must have a 'sites' array" };
  }
  const seen = new Set();
  for (let i = 0; i < config.sites.length; i++) {
    const site = config.sites[i];
    if (!site || typeof site !== "object") {
      return { valid: false, error: `Site ${i}: must be an object` };
    }
    if (typeof site.url !== "string" || !site.url.match(/^https?:\/\//)) {
      return { valid: false, error: `Site ${i}: url must start with http:// or https://` };
    }
    if (typeof site.label !== "string" || site.label.trim() === "") {
      return { valid: false, error: `Site ${i}: label must be a non-empty string` };
    }
    if (seen.has(site.url)) {
      return { valid: false, error: `Site ${i}: duplicate url "${site.url}"` };
    }
    seen.add(site.url);
  }
  // Optional: where "Edit in veditor" opens files (see veditor-launch.js).
  const urlError = validateMetabrowseUrl(config.metabrowse_url);
  if (urlError) return { valid: false, error: urlError };
  return { valid: true };
}

export async function loadConfig() {
  // Try GitHub first
  try {
    const remote = await fetchConfigFromGitHub();
    if (remote !== null) {
      const result = validateConfig(remote);
      if (result.valid) {
        await chrome.storage.local.set({ [STORAGE_KEY]: remote });
        return remote;
      }
      console.warn("barouse: remote config invalid, using local cache:", result.error);
    }
  } catch (err) {
    console.warn("barouse: GitHub fetch failed, using local cache:", err);
  }

  // Fall back to local cache
  const result = await chrome.storage.local.get(STORAGE_KEY);
  if (result[STORAGE_KEY]) {
    return result[STORAGE_KEY];
  }

  // First run — no local cache either
  const defaultConfig = getDefaultConfig();
  await chrome.storage.local.set({ [STORAGE_KEY]: defaultConfig });
  return defaultConfig;
}

export async function saveConfig(config) {
  await chrome.storage.local.set({ [STORAGE_KEY]: config });

  try {
    await pushConfigToGitHub(config);
  } catch (err) {
    console.error("barouse: GitHub push failed, saved locally only:", err.message);
  }
}
